<?php
return [
    'name' => 'User Activities',
    'slug' => 'activity',
    'description' => 'Addon to keep record or your member and there friends activities on the site'
];