<?php

return [

    'enable-recent-boxes' => [
        'type' => 'boolean',
        'title' => 'Enable Recent Boxes',
        'description' => 'Enable recent boxes side bar',
        'value' => '1',
    ],

];