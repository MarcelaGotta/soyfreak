<?php


Theme::asset()->add('cbox-css', 'custombox::css/cbox.css');