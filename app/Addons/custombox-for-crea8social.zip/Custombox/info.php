<?php
return [
    'name' => 'Custom Boxes Addon',
    'slug' => 'custombox',
    'description' => 'Create own Boxes for sidebar'
];