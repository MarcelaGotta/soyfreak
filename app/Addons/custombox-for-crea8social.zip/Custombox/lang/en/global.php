<?php
return [
    'recent-boxes' => 'Boxes Recentes',

];